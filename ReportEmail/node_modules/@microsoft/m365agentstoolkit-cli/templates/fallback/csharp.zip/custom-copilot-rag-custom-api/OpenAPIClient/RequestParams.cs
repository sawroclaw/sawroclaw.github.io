namespace OpenAPIClient
{
    public class RequestParams
    {
        public object PathObject;
        public object QueryObject;
        public object HeaderObject;
        public object RequestBody;
        public RequestParams() { }
    }
}